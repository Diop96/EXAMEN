namespace Application.entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Service.Spatial;

    [Table("Employe")]
    public partial class Employe
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Matricule { get; set; }

        [Required]
        [StringLength(50)]
        public string Prenom { get; set; }

        [Required]
        [StringLength(50)]
        public string Nom { get; set; }

        [Required]
        [StringLength(50)]
        public string Sexe { get; set; }

        public int NbreEnfants { get; set; }

        public int Anciennete { get; set; }

        public float SalaireBase { get; set; }

        [Required]
        [StringLength(10)]
        public string Statut { get; set; }

        public float PrimeSpecial { get; set; }

        public float Prime { get; set; }

        [Required]
        [StringLength(50)]
        public string Ipres { get; set; }

        [Required]
        [StringLength(50)]
        public string Service { get; set; }
    }
}
